package maze;

/**
 * 
 */

/**Interface needed
 * @author Elijah
 *
 */
public interface Runner {
	public static final int UP =0;
	public static final int DOWN =1; 
	public static final int LEFT =2;
	public static final int RIGHT =3;
	public static final int Up =0;
	public static final int Down =1; 
	public static final int Left =2;
	public static final int Right =3;
	public static final int up =0;
	public static final int down =1; 
	public static final int left =2;
	public static final int right =3;
	/**Get Move Of Runner!
	 **/
	int getMove();
	
	
}
