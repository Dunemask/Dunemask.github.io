/**
 * 
 */
package runners;

import java.awt.Color;
import maze.MazeRunner;
import maze.Runner;

/**
 * @author YOU!
 *
 */
public class SampleRunner extends MazeRunner {
	private static final Color color = new Color(0,0,0); //RGB Format!
	private static final String name = "Sample Runner!";
	public SampleRunner() {
		super(color, name);
	}

	/* (non-Javadoc)
	 * @see maze.Runner#getMove()
	 * The Only rule is that you cannot *teleport* to the end without traveling the distance.
	 * Program WILL use this to get a move Directions are:
	 * Runner.Right== 3
	 * Runner.Up==0
	 * Runner.left==2
	 * Runner.down==1
	 * Can use commands such as: wallAbove(),wallBelow(),wallRight(),wallLeft().
	 * Use the object notation for a list of other variables this.exampleFunction();
	 * Other commands can be used so long as the maze program itself is not moddified
	 * GOOD LUCK!
	 */
	@Override
	public int getMove() {
		// TODO 
		int direction = 1;
		//Note that direction = 1 is equivalent to direction = Runner.down
		direction  = Runner.DOWN;
			
		return direction;
	}
	

}
