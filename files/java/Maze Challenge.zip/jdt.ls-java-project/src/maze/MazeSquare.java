package maze;
import java.awt.Color;

/**
 * 
 */

/**
 * @author Elijah
 *
 */
public class MazeSquare {

	private Color color;
	private boolean wall;
	private int x;
	private int y;
	private boolean flagged;

	public MazeSquare(int x,int y,boolean wall,boolean flagged) {
		this.x = x;
		this.y = y;
		this.wall=wall;
		this.color = color(wall);
		this.setFlagged(flagged);
	}

	/**
	 * @param wall
	 * @return
	 */
	private Color color(boolean wall) {
		
		if(wall) {
			return Color.DARK_GRAY;
		}else {
			return Color.LIGHT_GRAY;
		}
	}
	/**Get Color of MazeSquare
	 **/
	public Color getColor() {
		return color;
	}
	/**Set Color of MazeSquare
	 * @param color Color for MazeSquare
	 * */
	public void setColor(Color color) {
		this.color = color;
	}
	/**Get if the MazeSquare is a wall
	 * */
	public boolean isWall() {
		return wall;
	}
	/**Set the wall to be a wall
	 * */
	public void setWall(boolean wall) {
		this.wall = wall;
		this.color = color(wall);
	}
	/**Will Get the Absolute X Location of the square on the JPanel
	 * */
	public int getX() {
		return x;
	}
	/**Will Set the Absolute X Location of the square on the JPanel
	 * @param x New X location of the square.
	 * */
	public void setX(int x) {
		this.x = x;
	}
	/**Will Get the Absolute Y Location of the square on the JPanel
	 * */
	public int getY() {
		return y;
	}
	/**Will Set the Absolute Y Location of the square on the JPanel
	 * @param x New Y location of the square.
	 * */
	public void setY(int y) {
		this.y = y;
	}

	public boolean isFlagged() {
		return flagged;
	}

	public void setFlagged(boolean flagged) {
		this.flagged = flagged;
	}
	
}
