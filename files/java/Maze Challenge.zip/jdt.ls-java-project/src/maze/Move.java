package maze;
/**
 * 
 */

import javax.swing.JFrame;

/**
 * @author Elijah
 *
 */
public class Move {

	
	public static MazeRunner[] moveRunners(MazeRunner[] runner,MazeSquare[][] maze) {
		
		for(int i=0;i<runner.length;i++) {
			if(runner[i]!=null) {
				int direction = runner[i].getMove();
		
				boolean canMove = canMove(runner[i],direction,maze);
				if(canMove) {
					runner[i] = moveRunner(runner[i],direction);
					//System.out.println(runner[i].getX());
				//	System.out.println(runner[i].getY());
				}
		
			}
		}//Close for loop
		
		return runner;
		
	}

	/** Returns if the runner can move or not
	 * @param runner
	 * @param direction 
	 * @return
	 */
	protected static boolean canMove(MazeRunner runner, int direction,MazeSquare[][] maze) {
		
		switch (direction) {
		case Runner.UP: return !wallAbove(runner,maze);
		case Runner.DOWN: return !wallBelow(runner,maze);
		case Runner.LEFT: return !wallLeft(runner,maze);
		case Runner.RIGHT: return !wallRight(runner,maze);
			
		
		
		}
		
		
		return true;
	}
	
	protected static MazeRunner moveRunner(MazeRunner runner,int direction) {
		int x= runner.getX();
		int y= runner.getY();
	
		switch (direction) {
		
		case Runner.UP:
			y= y-1;
			break;
		case Runner.DOWN:
			y= y+1;
			break;
		case Runner.LEFT:  
			x=x-1;
			break;
		case Runner.RIGHT:
			x= x+1;
			break;
		}
		
		runner.setX(x);
		runner.setY(y);
		return runner;	
	}

	/**
	 * @param frame
	 * @param maze
	 * @param runner
	 */
	public static void run(JFrame frame, MazeSquare[][] maze, MazeRunner[] runner) {
		try {
			Thread.sleep(Play.wait);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		frame.repaint();
		frame.revalidate();
		
		boolean done=false;
		boolean finished;
		while(!done) {
			Move.moveRunners(runner,maze);
			try {
				Thread.sleep(Play.speed);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}
			
			frame.repaint();
			frame.revalidate();
			
			for(int i=0;i<runner.length;i++) {
				if(runner[i]!=null) {
				
					int x = runner[i].getX();
					int y = runner[i].getY();
					finished = x== maze.length-2 && y== maze.length-2;
					if(finished) {
						Play.finished(frame,runner);
						done=true;
					}
				
				}//Close Testing runner exists
				
			}//Close Forloop
			
		}//Close WhileLoop
		
	}
	
	public static boolean wallAbove(MazeRunner r,MazeSquare[][] maze) {
		int x = r.getX();
		int y = r.getY();
		return maze[x][y-1].isWall();
		
		
	}
	
	public static boolean wallBelow(MazeRunner r,MazeSquare[][] maze) {
		int x = r.getX();
		int y = r.getY();
		return maze[x][y+1].isWall();
		
		
	}
	public static boolean wallRight(MazeRunner r,MazeSquare[][] maze) {
		int x = r.getX();
		int y = r.getY();
		return maze[x+1][y].isWall();
		
		
	}
	
	public static boolean wallLeft(MazeRunner r,MazeSquare[][] maze) {
		int x = r.getX();
		int y = r.getY();
		return maze[x-1][y].isWall();
		
		
	}
}
