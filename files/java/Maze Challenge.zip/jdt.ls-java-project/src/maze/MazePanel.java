/**
 * 
 */
package maze;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

/**
 * @author Elijah
 *
 */
public class MazePanel extends JPanel {

	/**Serial ID
	 * 
	 */
	private static final long serialVersionUID = 1934366591957288961L;
	/**The MazeSquare array used to create the maze.
	 **/
	private MazeSquare[][] maze;
	private int squareSize;
	private MazeRunner[] runner;
	private int frameSize;
	/**Creates a new Panel based on the maze given
	 * @param maze Array of MazeSquares
	 * @param squareSize size for sqaures going to be painted
	 * @param runner 
	 */
	public MazePanel(MazeSquare[][] maze,int squareSize, MazeRunner[] runner,int frameSize) {
		this.maze=maze;
		this.squareSize=squareSize;
		this.setRunner(runner);
		//Create ScoreBoard
		this.setLayout(null);
		this.setBackground(Color.black);
		this.frameSize = frameSize;
		//panel.setBounds(frameSize, 0, mazeSize*5, frameSize);
		//Set Lables
		
	}
	
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		//If it isn't working, try reversing i and c
		//Paint Squares
		setMaze(Play.maze);
		MazeSquare m;   
		for(int i=0;i<maze.length;i++) {			
			for(int c=0;c<maze.length;c++) {
				m =maze[i][c];

				g.setColor(m.getColor());
				if(maze[maze.length-2][maze.length-2]==m){
					g.setColor(Color.GREEN);
				}
				if(m.isFlagged()) {
					g.setColor(Color.cyan);
				}
				g.fillRect(m.getX(), m.getY(), squareSize, squareSize);
			}
			
		//Paint Runners	
		int absx,absy;
		for(MazeRunner r: runner) {
			if(r!=null) {
			g.setColor(r.getColor());
			absx = squareSize*r.getX();
			absy = squareSize*r.getY();
			g.fillOval(absx, absy, squareSize-5, squareSize-5);
			}
		}//Close ForLoop
			
		}
		//Paint Scores
		String score;
		for(int i=0;i<runner.length;i++) {
			if(runner[i]!=null) {
				score = String.valueOf(Play.score[i]);
				g.setColor(runner[i].getColor());
				g.fillRect(frameSize, i*squareSize, 5*squareSize, squareSize);
				g.setColor(Color.white);
				g.fillRect(frameSize+9, i*squareSize+9, 4*squareSize+14, squareSize-14);
				g.setColor(Color.black);
				g.drawString(score+"   "+runner[i].getName(), frameSize+10, i*squareSize+20);
			}
		}
	
		
	}
	/**Get Active MazeSqauare
	 * */
	public MazeSquare[][] getMaze() {
		return maze;
	}
	/**Set new MazeSquare
	 * @param maze New Maze
	 * @deprecated
	 * */
	public void setMaze(MazeSquare[][] maze) {
		this.maze = maze;
	}
	/**Get Active MazeSqauare Size
	 * */
	public int getSquareSize() {
		return squareSize;
	}
	/**Set new MazeSquare Size
	 * @param squareSize New Squaresize
	 * @deprecated
	 * */
	public void setSquareSize(int squareSize) {
		this.squareSize = squareSize;
	}
	/**Get list of MazeRunners
	 * */
	public MazeRunner[] getRunner() {
		return runner;
	}
	/**Set list of MazeRunners
	 * @param runner New List of runners
	 * @deprecated
	 * */
	public void setRunner(MazeRunner[] runner) {
		this.runner = runner;
	}


}
