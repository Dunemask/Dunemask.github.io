package maze;

import java.util.Random;

public class Generatemaze {

	/**Create a new array of MazeSquares.
	 * @param size Size of square (Will make the square sizexsize)
	 * @param iterations Should be a fairly large number
	 * */
	public static MazeSquare[][] newmaze(int size,int iterations){
		
		MazeSquare[][] mg = new MazeSquare[size][size];
		//1 Is Path, 0 is wall;		
		Random r = new Random();
			//Creates empty array
		for(int i = 0; i < size; i++) {
			for(int c=0;c<size;c++) {
				mg[i][c] = new MazeSquare(size*i,size*c,true,false);

			}
			
			
		}
		
		
				//"Moves" to the middle
				int mx = (size/2)-2;
				int my = (size/2)-2;
				for(int i = 0; i <= iterations; i++) {
					mg[mx][my].setWall(false);//sets the point it is on to not wall
					int choice = r.nextInt(4); // chooses the direction
					switch(choice) {
						case 0: if ((mx+2 < size-1 )) {
									if(mg[mx+2][my].isWall()) { //if in bounds and 2 in front of it is wall
										mg[mx+1][my].setWall(false);	//then sets the one in front to path
									}
									mx += 2;				//always moves two unless outside of bounds
								}
								break;
						case 1: if ((mx-2 > 0)) {			//repeats for all 4 directions
							if(mg[mx-2][my].isWall()) {			//could be expanded for 6 directions easily
								mg[mx-1][my].setWall(false);;
							}
							mx -= 2;
						}
						break;
						case 2: if ((my+2 < size-1 )) {
							if(mg[mx][my+2].isWall()) {
								mg[mx][my+1].setWall(false);;
							}
							my += 2;
						}
						break;
						case 3: if ((my-2 > 0)) {
							if(mg[mx][my-2].isWall()) {
								mg[mx][my-1].setWall(false);;
							}
							my -= 2;
						}
						break;
					}
				}
			
				
				
				
				
				
				
				return mg;
		
		
		
	}
	
}   //Initial Coding Intillectual Copyright of Jason Roberts (c)
