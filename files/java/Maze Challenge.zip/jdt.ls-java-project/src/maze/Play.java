/**
 * 
 */
package maze;

import javax.swing.JFrame;

import runners.*;

/**The main class
 * <p> Edit the addrunner method to add runners 
 * @author Elijah
 *
 */
public class Play {
	/**Size Of Array
	 * */
	public static int mazeSize =27; //-4 Increments 4x=3
	/**Wait TIme Before Program Starts (Milliseconds)
	 * */
	public static int wait = 1000;
	/**Array OF MazeSquares
	 * */
	public static MazeSquare[][] 	maze = Generatemaze.newmaze(mazeSize, 100000);
	/**The Thread.sleep Timer countdown
	 * */
	public static int speed = 100;
	/**Scores for program
	 * */
	public static int score[]= new int[20];
	/**Main Entry Point
	 * @param args
	 */	
	public static void main(String[] args) {
		while(true) {
		
		MazeRunner[] runner = addRunners(); 
		JFrame frame = mazeFrame(mazeSize,maze,runner);
		frame.setLocationRelativeTo(null);
		//frame.toBack();
		Move.run(frame,maze,runner);
		}
	}

	/**Add Runners (This is where you add your runners)
	 * @param runners
	 * @return
	 */
	private static MazeRunner[] addRunners() {
		//Add the runners
		MazeRunner[] mazeRunner = new MazeRunner[20];
		mazeRunner[0] = new SampleRunner();
		//mazeRunner[1] = new RightWallRunner();
		//mazeRunner[2] = new DumbRunner();
		//mazeRunner[3] = new LeftWallRunner();
	    //mazeRunner[4] = new DuneRunner();
	    //mazeRunner[5] = new Blocker();
		return mazeRunner;
	}

	/**Create new Maze
	 * @param mazeSize
	 * @param maze
	 * @return
	 */
	private static JFrame mazeFrame(int mazeSize, MazeSquare[][] maze,MazeRunner[] runner) {
		int frameSize = (mazeSize)*(mazeSize);
		JFrame frame = new JFrame("Maze Runner");
		frame.setSize(frameSize+(mazeSize*5), frameSize+35); //39 is the bar height
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Add The MazePanel
		MazePanel mz = new MazePanel(maze,mazeSize,runner,frameSize);
		frame.add(mz);
		
	//	JPanel scoreBoard = scoreBoard(runner,frameSize,mazeSize);
	//	scoreBoard.setBounds(frameSize, 0, mazeSize*5, frameSize);
	//	frame.add(scoreBoard);
		
		frame.setVisible(true);
		return frame;
	}
	/**What the Program Does When Finished
	 * */
	public static void finished(JFrame frame, MazeRunner[] runner){
		for(int i=0;i<runner.length;i++) {
			if(runner[i]!=null) {
			
				int x = runner[i].getX();
				int y = runner[i].getY();
				boolean finished = x== maze.length-2 && y== maze.length-2;
				if(finished) {
					Play.score[i]++;
				}
			}
			
		}
		//Print Scores to command line
	/*	for(int z=0;z<=4;z++) {
			System.out.println(runner[z].getName()+":"+score[z]);
		}*/
		//Wait and restart
		try {
			Thread.sleep(wait);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		maze = Generatemaze.newmaze(mazeSize, 100000);
		frame.dispose();
		
		//Play.main(null);
	}

}
