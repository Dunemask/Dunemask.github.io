package maze;
import java.awt.Color;

/**
 * 
 */

/**
 * The Runner Object
 * @author Elijah
 *
 */
public abstract class MazeRunner implements Runner {
	private Color color;
	private String name;
	private int y;
	private int x;
	public final static int UP =0;
	public final static int DOWN =1;
	public final static int LEFT =2;
	public final static int RIGHT =3;
	private MazeSquare[][] maze;
	/**Create new Maze Runner
	 * @param name 
	 * 
	 */
	public MazeRunner(Color color, String name) {
		this.x=1;
		this.y=1;
		this.color = color;
		this.setName(name);
		this.maze = Play.maze;
		
	}
	public void setMaze(MazeSquare[][] maze) {
		this.maze = maze;
	}
	public MazeSquare[][] getMaze() {
		return maze;
	}
	
	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public boolean wallAbove() {
		x = this.getX();
		y = this.getY();
		return maze[x][y-1].isWall();
		
		
	}
	
	public boolean wallBelow() {
		x = this.getX();
		y = this.getY();
		return maze[x][y+1].isWall();
		
		
	}
	
	public boolean wallRight() {
		x = this.getX();
		y = this.getY();
		return maze[x+1][y].isWall();
		
		
	}
	
	public boolean wallLeft() {
		x = this.getX();
		y = this.getY();
		return maze[x-1][y].isWall();
		
		
	}
	
	public boolean wall(int direction){
		boolean isWall = false;
		switch (direction){
		case Runner.UP: isWall = wallAbove();
		break;
		case Runner.DOWN: isWall = wallBelow();
		break;
		case Runner.RIGHT: isWall = wallRight();
		break;
		case Runner.LEFT: isWall =wallLeft();
		break;
		
		}
		return isWall;
		
	}





}
